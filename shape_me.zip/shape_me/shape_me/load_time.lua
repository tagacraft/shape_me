-- mod shape_me : work to done at load time :



--[[ compatibility with mod security, accessing files :
minetest core mod "security" disallow most of external os commands, like file access.
I want my mod to be the easyest to install and use for server's owner & singleplayers, so
i deal with this feature.
I see that the core mod security allow to :
- at load time : access file in my mod folder & world folder only;
- at run time : access granted to world folder only;

so :
mod shape_me_linker, like any other mod, is a foreign mod for shape_me's point of view;
all data files needed to be (or supposed to be) read/writen/updated either
at runtime or by foreign mod are stored in (in preference & tested order) :
- 1°) <world path> / "shape_me" / file_name.dat ;	<- "shape_me" is folder
- 2°) <world path> / "shape_me_" file_name.dat.		<- "shape_me_" is prefix of file_name

data files :
------------
	- mods2call.dat 		: description of whitch mods are callable and whitch functions
	- pendings.dat			: blocks hit in game but waiting for approval by accredited player
	- blocks2process.dat	: approved blocks to be registered by foreign mods at load time; this
				last file grow by the time, containing all the blocks ever hit in-game to be 
				processed by foreign mods.
]]

do -- register privileges for this mod :
minetest.register_privilege("shape_me_user", {
    description = "Can uses the shape_me tool",
    give_to_singleplayer = shape_me.settings.give_privs_to_single(),
})
minetest.register_privilege("shape_me_controler", {
    description = "Can validate hit blocks and mods to be called for those blocks from next server restart",
    give_to_singleplayer = shape_me.settings.give_privs_to_single(),
})
minetest.register_privilege("shape_me_admin", {
    description = "Can use all options of shape_me mod",
    give_to_singleplayer = shape_me.settings.give_privs_to_single(),
})
end
do -- load mods2call into shape_me.mods2call:
	local file_mods2call = shape_me.load_datafile("mods2call")
	if file_mods2call then 
		shape_me.mods2call = file_mods2call 
	else
		minetest.log("shape_me error : the mods2call.dat file has not been loaded. "..
			"error message from io.open is :\n"..err_msg)
		minetest.log("there is no mod to call for shape_me to work, perhaps later in-game by accredited player...")
	end
end
do -- check if shape_me/depends.txt have line for each mod to call :
	local depends_file = shape_me.check_dir(minetest.get_modpath("shape_me")).."depends.txt"
	local file, err_msg = io.open(depends_file, "r")
	local found
	shape_me.depends = {}
	for line in file:lines() do -- depends.txt file loaded
		table.insert(shape_me.depends, line)		
	end
	for k, _ in pairs(shape_me.mods2call) do -- add mod to depends.txt if needed :
		found = false
		for i, v in ipairs(shape_me.depends) do
			if k == v or k.."?" == v then
				found = true
				break
			end
		end
		if not found then
		-- add mod to depends
			table.insert(shape_me.depends, k.."?")
		end
	end
	do -- rewrite depends.txt :
		file, err_msg = io.open(depends_file, "w")
		if file then
			for i, v in ipairs(shape_me.depends) do
				file:write(v.."\n")
			end
			file:close()
			-- shape_me.mydebug("log", "depends.txt updated, content is "..dump(shape_me.depends))
		else
			minetest.log("shape_me load_time.lua error rewriting depends.txt; io error="..err_msg)
		end
	end
	
end

do -- process blocks2process file (call foreign mod's functions for each block listed)

	block_registered = {} -- must be global to work with <a_string_built_as_a_function>()

	local all_blocks2process = {}
	local a_block2process
	local mod_params
	local a_param
	local num_p
	local fields_available = {}
	local sep, i, str, node_name
	local tfield
	local func_string = ""
	local func2call = ""
	local func_exec
	local old_blocks_list = {}

	all_blocks2process = shape_me.blocks2process

	if table.length(all_blocks2process)==0 then return end
	for bname, params in pairs(all_blocks2process) do -- for each block 'bname' to process :
		for mod, do_it in pairs(params.mods) do -- for each mod the block wish to call :
			if do_it==true then -- some checks before working :
				if not minetest.registered_nodes[bname] then -- block exist ?
					minetest.log("shape_me error: in blocks2process file, "..
						bname.." is not a block in minetest.registered_nodes.")
					break
				end
				if not minetest.get_modpath(mod) then -- mod to call exist ?
					-- shape_me.mydebug("log", "the mod "..mod.." is not installed for registering "..a_block2process.node..".")
					break 
				end
				mod_params = shape_me.mods2call[mod]
				if mod_params==nil then -- foreign function to call designated ?
					-- shape_me.mydebug("log", "shape_me error : the mod "..mod.." is not registered to be called.")
					break
				end
			else goto nextmod
			end
			do -- retrieve all the fields from minetest.registered_nodes :
				block_registered = {}
				for k,v in pairs(minetest.registered_nodes[bname]) do
					block_registered[k] = v
				end
			end
			do -- add to block_registered{} the additionals fields we want to be available :
				sep = bname:find(":")
				block_registered.short_name = block_registered.name:sub(sep+1)
				block_registered.fields = minetest.registered_nodes[bname]
			end
			-- for the node block_registered, call each function :
			do -- clone minetest.registered_nodes before calling foreign function :
				if mod_params.add_missing_fields==true then -- if false, useless to make the list
					old_blocks_list = {}
					for k, _ in pairs(minetest.registered_nodes) do
						old_blocks_list[k] = true -- easyest to compare later...
					end
				end
			end
			for _, params in ipairs(mod_params) do -- build each foreign function & call it :
				func_string = params.func_name.."("
				num_p = 1
				while params.parameters[num_p] do -- build each parameter's string representation
					if num_p>1 then func_string = func_string..", " end
					a_param = params.parameters[num_p]
					i = 1
					str = ""
					while a_param.value_type[i] do
						if i>1 then str=str..".." end
						tfield = a_param.value_type[i]
						if tfield=="field" then
							-- shape_me.mydebug("log", "field to add to params2provide{} is "..	a_param.value[i].." (type "..type(block_registered[a_param.value[i]]).. ")")
							if type(block_registered[a_param.value[i]]) == "table" then
								str = str.."block_registered."..a_param.value[i]
							else
								str = str..'"'..
							string.gsub(block_registered[a_param.value[i]],'"','\"')..'"'
							end
						elseif tfield=="nostring" then
							str = str..a_param.value[i]
						else -- supposed to be "string" :
							str = str.. '"' .. string.gsub(a_param.value[i],'"', '\"' ) .. '"'
						end						
						i = i+1
					end
					func_string = func_string..str
					num_p = num_p+1
				end
				func_string = func_string..")"
			--[[ call the function for registering by the foreign mod designated :
				 function call (parameters) will be include in a string, as it should be 
				 written directly inside lua code file by a human codder,
				 like: func_string = register_function(parameter1, parameter2, ...)
				 then local func_call = loadstring(func_string)
				 and finally: func_call()
				 func_call() will work exactly in the same way as if you had written
				 register_function(parameter1, parameter2, ...) in the code
			]]
				do -- call foreign function :
					func_exec = loadstring(func_string)
					func_exec()
				end
			end
			if mod_params.add_missing_fields==true then -- if false, useless to continue
				local added_block = {}
				for k, v in pairs(minetest.registered_nodes) do
					if not old_blocks_list[k] then -- new block detected
						added_block = {}
						for k1, v1 in pairs(v) do added_block[k1] = v1 end -- clone this new block
						for k1, v1 in pairs(block_registered) do -- for each field of source block :										
							if not added_block[k1] and -- new block miss this field
							not string.find("fields short_name", k1) then -- not field added by shape_me
								if shape_me.test_rules_for_blockfield(block_registered, k1, mod_params.add_missing_rules) then
									added_block[k1] = v1
									-- shape_me.mydebug("log", "block "..k.." : added field ".. k1.." = "..dump(v1)	)
								end
							end
						end									
						if block_registered.mod_origin then -- special act for this field
							added_block.mod_origin = block_registered.mod_origin
								--(mod stairs (perhaps others mods too) modify it to "shape_me" but i'm not the
								-- author of this new block, only a linker between origin and shaper mod)
						end
						minetest.register_node(":"..k, added_block)
					end
				end
			end
			::nextmod::
		end
	end
	block_registered = nil
end
