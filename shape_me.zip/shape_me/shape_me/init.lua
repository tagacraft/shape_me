--[[ mod shape_me by Tagada 2018, april 19th - june 12th

what this mod does :
	the idea is to allow any mod that do something like shaped blocks from a full block to
	be called in game by shape_me when a player has clicked a full block;
	then the foreign mod's appropriate's function will be called on next server restart.
	
	player need some priv to use the tool intended to hit blocks and to access some functions :
	"user" priv can use the tool; the hit block will wait for approval before to do anything else;
	"controler" priv can approve blocks; approved block will go to a list of blocks to process2add
		from next server restart;
	"admin" priv can do all possibles actions with this mod
]]

-- context variable "shape_me{}" declared in shape_me_linker/init.lua
-- check if shape_me_linker end it's loading correctly :
if shape_me==nil then return false end

-- shape_me do some work at load time :
dofile(minetest.get_modpath("shape_me").."/load_time.lua")

-- and do the interactive work at run time :

--[[ define formspecs :
	defining formspec into something like an object-structure is a seed for an independant mod
	that should enable modder to visualy define formspecs in-game...
]]

local formspecs = {}
formspecs.summary = { -- show summary of what will be done after hit a block / node
	-- fields for all the pages (always visible)
	size = {type="size",w=12, h=8},
	tabheader = {
		type = "tabheader",
		x = 0, 	y = 0,
		captions = {"hit block","pending blocks","admin options"},
		related_level = "controler admin",
		captions_related_level = {					-- shown accordingly to player's priv 
			["hit block"] = "user controler admin",
			["pending blocks"] = "controler admin",
			["admin options"] = "admin"
		},
		current_tab = 1,
		transparent = false,
		draw_border = rgbToHex({255,0,0}),
	},	
	btn_maj = {
		type = "button",
		related_level = "admin",
		x = 0.5, 	y = 7,
		w = 2, 		h = 1,
		label = "refresh",},
	proceed = {
		type = "button_exit",
		x = 3, 	y = 7,
		w = 2,	h = 1,
		label = "OK"},
	cancel = {
		type = "button_exit",
		x = 5.5,	y = 7,
		w = 2,	h = 1,
		label = "Cancel"},		
	-- fields for page 1 (tabheader's caption "hit block" : tabheader.current_tab=1) :
	-- acces granted to all 'shape_me:'privs;
	summary = {
		type = "label",
		x = 0.2,	y = 0.2,
		w = 8,		h = 4,		
		label = "here come the explanations about what will be done with hit block.",
		default = "",
		page = 1,
	},
	approve = {
		type = "checkbox",
		related_level = "controler admin", -- shown only to those privs
		x = 0.5, y = 5,
		selected = true,
		label = "As an accredited player, I approve this block to be processed.\n"..
			"(skip approval step, directly register block to be processed from next restart).",
		page = 1,
	},
	-- fields for page 2 (tabheader.current_tab=2, "pending blocks") :
		-- access granted to priv 'shape_me:controler' & 'shape_me:admin';
		-- a table of mods to register for the actual hit block if any, with ability to 
		-- enable/disable each mod, plus like above, all blocks waiting for approval to 
		-- be registered for being processable from next restart;
	pending_title = {
		page = 2,
		type = "label",
		x = 1, y = 0.5,
		label = "Blocks waiting for your approval :"
	},
	pendings = {
		page = 2,
		type = "table",
		hscrollbar = "hscrollbar", -- horizontal scrollbar attached to this table
		slideBy = 2,				-- number of columns to slide at once
		colsFixed = 2,				-- firsts columns that dont slide
		cols2slide = 4,				-- number of columns to slide
		valPerCols = 250,			-- deplacement of scrollbar's cursor needed to slide a
									-- slideBy columns
		fstCol2show = 3,			-- 1st slidable column to show accordingly to actual scrollbar
									-- cursor position
		x = 2, y = 1,
		w = 6, h = 2,
		maxcols = 6,				-- while building formspec string, fill empty cols up to this
		cells = {					-- odd columns point image 1=uncheck, 2=check
			{2, "current block",   2, "mod #1"},
			{1, "pending block 1", 1, "mod #1", 1, "moreblocks"},
			{2, "pending block 2"},
		},
		selected_idx = 1,
		col_def = {
		  [1] = {
			type = "image",
			options = { [1] = "check_no.png", [2] = "check_yes.png" }
			},
		  [2] = { type = "text" },
		  [3] = {
			type = "image",
			options = { [1] = "check_no.png", [2] = "check_yes.png" }
			},
		  [4] = { type = "text" },
		  [5] = {
			type = "image",
			options = { [1] = "check_no.png", [2] = "check_yes.png" }
			},
		  [6] = { type = "text" },
		},
	},
	hscrollbar = {
		page = 2,
		type = "scrollbar",
		associated_table = "pendings",
		x = 2, y = 3,
		w = 6, h = 0.22,
		orientation = "horizontal",
		value = 1,
		},
	approve_all = { --[[ shown on page 2 (build only for level >= controler),
			if true, all pending blocks will be check to true
		]]
		type = "checkbox",
		-- related_level = "controler admin",
		x = 1, y = 3.5,
		selected = true,
		label = "(un)check all blocks",
		page = 2,
	},
	remove_disapproved = {
		type = "checkbox",
		-- related_level = "controler admin",
		x = 1, y = 4,
		selected = true,
		label = "on click 'ok' button, remove all\n"..
				"unapproved blocks from pendings list",
		page = 2,
	},
	-- fields for page 3 ("admin options"):
		-- acces granted to priv 'shape_me:admin' only;
		-- modify all possible options of this mod;
		-- idea : an helper to analyse foreign mod's lua files, find&show foreign register functions
		-- to enable a pre-existing shaping mod to be called by shape_me even if 
		-- the foreign mod had not called the shape_me_linker:register_me() function.
	
	}

-- functions about administrating formspecs :
forms = {}
forms = {
	content = {},
	add_formspec = function(formspec, fname, update)
		if formspec==nil then return false, "form spec was nil" end
		if fname==nil then return false, "form need a name" end
		if update==nil then update=false end
	
		-- check if name already set
		if forms.content[fname] then
			-- already set, what about "update" parameter ?
			if update==false then return false, "the form was already set" end
			-- update the form : same elements will be replaced
			forms.content[fname] = formspec
			return true		
		else
			forms.content[fname] = formspec
			return true
		end
	end,
	load_file = function(fname) -- load from file a generic form
		if fname==nil then return false end

		local file_str = shape_me.check_dir(shape_me.files.root)..
					shape_me.check_dir(shape_me.files.dir)..
					shape_me.files.prefix..fname..".dat"
		local file, err = io.open(file_str,"r")
		if file==nil then 
			shape_me.mydebug("log", "error loading form "..file_str.." error msg: "..err)
			return false, err 
		end
		local a_form
		local txt = file:read("*all")
		shape_me.mydebug("log", "content of file shape_me/"..fname.." is :"..dump(txt))
		a_form = minetest.deserialize(txt)
		shape_me.mydebug("log", "forms.load(\""..fname.."\")->deserialize :"..dump(a_form))
		file:close()
		forms.add_formspec(a_form, fname, true)
	end,
	save_to_file = function(fname) -- save to file a generic form
		if fname==nil then return false end
		if forms.content[fname] == nil then return false end
		
		local file_str = shape_me.check_dir(shape_me.files.root)..
						 shape_me.check_dir(shape_me.files.dir)..
						 shape_me.files.prefix..fname..".dat"
		
		local file = io.open(file_str,"w")		
		file:write("return "..dump(forms.content[fname]))
		file:close()
	end,
	update_element = function(def_update)
	--[[ update some field(s) of an element of a formspec;
		def_update = { 
			where_player_name 		= "name_of_the_player_to_update_the_form",
			where_element_name 		= "name of the element to update",
			update_fields 			= {field1 = value, field2 = value, ... },
			add_missing_elem		= true / false,
			add_missing_field		= true / false
		}
	]]
	
		if def_update==nil then return false, "form to update not defined (got nil)" end
		if def_update.where_player_name == nil then return false, "player name to update not defined (got nil)" end
		if def_update.where_element_name == nil then return false, "element name to update not defined (got nil)" end
		if def_update.update_fields == nil then return false, "parameter update_fields not defined (got nil)" end
	
		local pname = def_update.where_player_name
		local elm2find = def_update.where_element_name
		local updtflds = def_update.update_fields
		local updated = -1 -- number of updated fields; -1 at start means elm2find not found
		
		if shape_me.players[pname].form==nil then return false end
		-- retrieve the element to update
		if def_update.add_missing_elem==true and shape_me.players[pname].form[elm2find]==nil then
			shape_me.players[pname].form[elm2find]={}
		end
		if shape_me.players[pname].form[elm2find]~=nil then
			updated = 0
			for field, value in pairs(updtflds) do
				-- for each field contained in updtflds, update the same field of form[elm2find]
				if shape_me.players[pname].form[elm2find][field]~=nil or
				def_update.add_missing_field==true then
					shape_me.players[pname].form[elm2find][field] = value
					updated = updated + 1
				end
			end
			return true, tostring(updated).." field(s) updated in "..elm2find
		end
		-- code execution come here if :
		-- element to update is not found and add_missing_elem is false or nil
		return false, "element "..elm2find.." not found for player "..pname
	end,
	toggle_tablecell = function(pname, field, row, col) -- toggle (un)check cells
		--[[ in a table.cells element, considering that odd columns contain '1' or '2' defining
		respectively unchecked and checked checkbox's image, toggle the value from 1 to 2 and 
		2 to 1	]]
		local form = shape_me.players[pname].form
		if form[field]==nil then return false, "field not defined" end
		if form[field].type~="table" then return false, "field was not a table" end
		row = tonumber(row)
		col = tonumber(col)
		local colScrolled = col -- take account of scrollbar
		if col > form[field].colsFixed then
			colScrolled = col-(form[field].colsFixed+1)+form[field].fstCol2show
		end
		-- if colScrolled is even, point to previous column (checkbox's image is in odd column) :
		if colScrolled%2 == 0 then colScrolled = colScrolled-1 end
		-- toggle the value (if the column exist for this row):
		if form[field].cells[row][colScrolled]~=nil then
			form[field].cells[row][colScrolled] = 2-(form[field].cells[row][colScrolled]-1)
			-- say that player intend to modify some pending block :
			if row>1 then
				shape_me.players[pname].has_modified_pendings = true
			end
		end
		form[field].selected_idx = row
		shape_me.players[pname].form = form		
	end,
	update_scrollable_table = function(pname, scrollname)
		--[[ pname is the player_name;
			scrollname is the name of an element of type 'scrollbar' in ..[pname].form and
			[scrollname] have a field 'associated_table' which contain the name of the associated table;
			this function update the field fstCol2Show whitch is the first column to show accordingly to
			the value of the associated horizontal scrollbar
		]]
		local tbl_name = shape_me.players[pname].form[scrollname].associated_table
		local tbl = shape_me.players[pname].form[tbl_name]
		local scr = shape_me.players[pname].form[scrollname]
		
		tbl.fstCol2show = tbl.colsFixed+1+
			(math.floor(scr.value/tbl.valPerCols)*tbl.slideBy)
		shape_me.players[pname].form[tbl_name] = tbl
	end,
	update_form = function(fname, elements, add_missing)
		--[[ fname : the name of the form to update;
			elements = {
				field_name#1 = value,   : for each field, pairs name=value to update
				field_name#n = value...
			}
			add_missing = true / false : add missings elements and fields
		]]
		if fname==nil then return false, "need a form name" end
		if elements==nil then return false, "need elements to update" end		
		if forms.content[fname]==nil then return false, "form "..fname.." does not exist." end
		
		local form = forms.content[fname]
		shape_me.mydebug("both","update_form called for form "..fname.." with elements ="..
			dump(elements))
		for element, fields in pairs(elements) do
			if form[element]==nil and add_missing==true then form[element]={} end
			if form[element]==nil then goto nextelement end
			if type(fields) == "table" then
				for field, value in pairs(fields) do
					if form[element][field]~=nil or add_missing==true then
						form[element][field] = value
					end
				end
			-- else fields may be of form "name=value" as in 'fields' returned by 'on_player_receive_field'
			-- so there seems to be nothing to do here
			end
			::nextelement::
		end
		forms.content[fname] = form
		return true
	end,
	--[[ types of fields in a formspec :

	size		[w,h]
	list		[inventory_location;list_name;X,Y;W,H[;OPTIONAL:starting_item_index] ]
	image		[X,Y;W,H;texture_name]
	field		[X,Y;W,H;name;label;default]
	pwdfield	[X,Y;W,H;name;label]
	textarea	[X,Y;W,H;name;label]
	label		[X,Y;label]
	vertlabel	[X,Y;label]
	button		[X,Y;W,H;name;label]
	image_button		[X,Y;W,H;image;name;label]
	item_image_button	[X,Y;W,H;item name;name;label]
	button_exit			[X,Y;W,H;name;label]
	image_button_exit	[X,Y;W,H;image;name;label]
	listcolors	[slot_bg_normal;slot_bg_hover [;OPTIONAL:slot_border [;tooltip_bgcolor;tooltip_fontcolor] ] ]
	bgcolor		[color;fullscreen;]
	background	[X,Y;W,H;texture_name [;auto_clip] ]
	textlist	[X,Y;W,H;name;listelem 1,listelem 2,...,listelem n [;selected idx;transparent] ]
	dropdown	[X,Y;W,H;name;item1,item2,item3...;selected_id]
	checkbox	[X,Y;name;label;selected]
	tabheader 	x=<X>, y=<Y>, name="<name>", captions=<array of strings>, 
				current_tab=<current_tab>, transparent=<transparent>, drawborder=<drawborder>
	box			x=<X>, y=<Y>, w=<Width>, h=<Height>, color="<color>"
	table		[X,Y;W,H;name;cells{};selected idx]
	tablecolumns[<type 1>,<opt 1a>,<opt 1b>,...;<type 2>,<opt 2a>,<opt 2b>;...]
	--- other elements (see at http://dev.minetest.net/Lua_Table_Formspec search "Formspec"
	or file lua_api.txt) :

	nb: color is hex RRGGBB
	Inventory location:
		context: Selected node metadata (deprecated: "current_name")
		current_player: Player to whom the menu is shown
		player:<name>: Any player
		nodemeta:<X>,<Y>,<Z>: Any node metadata
		detached:<name>: A detached inventory
	
]]
	fields2export = { -- fields for a formspec, in the right order :
		size = {
			fields= {[1]="w",[2]=",h"} },
		list = {
			fields= {[1]="inventory_location", [2]=";list_name", [3]=";x", 
					 [4]=",y", [5]=";w", [6]=",h"},
			fields_optional = {[1]=";starting_item_index"} },
		image = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";texture_name"} },
		field = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";name", 
					 [6]=";label", [7]=";default"} },
		field_close_on_enter = {
			fields= {[1]="name", [2]=",close_on_enter"} },
		pwdfield = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";name", [6]=";label"} },
		textarea = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";name", 
					 [6]=";label", [7]=";default" }, },	
		label = {
			fields= {[1]="x", [2]=",y", [3]=";label"}},
		vertlabel = {
			fields= {[1]="x", [2]=",y", [3]=";label"}},
		button = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";name", [6]=";label"}},
		image_button = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";image", 
					 [6]=";name", [7]=";label"}},
		item_image_button = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";item_name", 
					 [6]=";name", [7]=";label"}},
		button_exit = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";name", [6]=";label"}},
		image_button_exit = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";image", [6]=";name", 
					 [7]=";label"}},
		list_colors = {
			fields= {[1]="slot_bg_normal", [2]=";slot_bg_hover"},
			fields_optional = {[1]=";slot_border", [2]=";tooltip_bgcolor", 
				[3]=";tooltip_fontcolor"}},
		bgcolor = {
			fields= {[1]="color", [2]=";fullscreen"}},
		background = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";texture_name"},
			fields_optional = {[1]=";auto_clip"} },
		textlist = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";name", [6]=";listelem{}"},
			fields_optional= {[1]=";selected idx", [2]=";transparent"} },
		dropdown = {		
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";name", [6]=";item{}", 
					 [7]=";selected_id"}},
		checkbox = {
			fields= {[1]="x", [2]=",y", [3]=";name", [4]=";label", [5]=";selected"}},
		box = {
			fields= {[1]="x", [2]=",y", [3]=";w", [4]=",h", [5]=";color"}},
		tabheader = {
			fields= {[1]="x", [2]=",y", [3]=";name", [4]=";captions{}", [5]=";current_tab"},
			fields_optional = {[1]=";transparent", [2]=";draw_border"}, 
		},
		table = {
			fields = {[1] = "x", [2] = ",y", [3] = ";w", [4] = ",h", [5] = ";name",
					  [6] = ";cells{}", [7] = ";selected_idx"}
		--[[ tablecolumns[<type 1>,<opt 1a>,<opt 1b>,...;<type 2>,<opt 2a>,<opt 2b>;...]
			specific implementation in forms.make_formspec() : tablecolumns must be inserted
			before the table[] element concerned.
		]]
			},
		-- scrollbar[<X>,<Y>;<W>,<H>;<orientation>;<name>;<value>]
		scrollbar = {
			fields = {[1] = "x", [2] = ",y", [3] = ";w", [4] = ",h", [5] = ";orientation",
					  [6] = ";name", [7] = ";value" }
		},
	},
	-- return a formated string containing the formspec "name" usable by mt.show_formspec() :
	make_formspec = function(pname, page) --[[ return the player pname's formspec's formated 
			string, with elements that have 'page' field defined to page or to nil	]]

		local form = shape_me.players[pname].form
		if (form==nil) then return false end

		local function process_fields(element, fields, fields_def, optional)
		-- return a formspec's element formated string (e.g. button, or textlist, or label, etc)
			local formated_string = ""
			local field_num -- , set_num
			local field_proto --[[ definition for a field containing :
					- eventualy a first char as separator : comma or semicolon;
					- the name of a field;
					- eventually 2 last chars as {} (parenthesis) specifiing the field is a table; ]]					
			local char1, mrk = "", "" -- the first and 2 last chars of field_proto;
			local list_elem = ""
			local t -- serve as shorter t=type(some_very_long_name)
			local colsFixed = 0   -- number of firsts columns that dont slide
			local fstCol2show = 1 -- the n� of the first slidable column to show
					
			if fields.type=="table" and fields.col_def~=nil and optional==false then 
			-- element is a table, insert first the options if exist :
			-- col_def lead to build a string like tablecolumns[parameters] to insert before
			-- the element table[]
				formated_string = "tablecolumns["
				list_elem = ""
				if fields.hscrollbar~=nil then
					colsFixed = fields.colsFixed or 0
					fstCol2show = fields.fstCol2show or 1
				end
				for i, opt in ipairs(fields.col_def) do
					if i>colsFixed and i< fstCol2show then goto nextcoldef end
					if opt.type==nil then goto nextcoldef end
					if list_elem~="" then list_elem = list_elem..";" end
					list_elem = list_elem..opt.type
					if opt.options==nil then goto nextcoldef end
					-- get key (or numeric) indexed options :
					for k, v in pairs(opt.options) do
						list_elem = list_elem..","..k.."="..minetest.formspec_escape(v)
					end
					::nextcoldef::
				end
				formated_string = formated_string..list_elem.."]\n"
			end
			if optional==false then
				formated_string = formated_string..fields.type.."["
			end
			field_num = 1
			while fields_def[field_num] do			
				field_proto = fields_def[field_num]	--[[  field_proto can contain :
					- s�parator like , or ;
					- field name ;
					- marker {} to say it is a list and elems will be separated by ","
				]]
				char1 = field_proto:sub(1,1)
				if field_proto:len()>2 then
					mrk = field_proto:sub(-2) -- the 2 last characters
				else
					mrk = ""
				end
				
				if char1=="," or char1==";" then
					formated_string = formated_string..char1
					field_proto = field_proto:sub(2) -- substract first char
				else
					char1="" -- was a part of field name so erase it
				end
				if mrk=="{}" then				
					field_proto = field_proto:sub(1,-3) -- substract 2 last chars
					list_elem = ""
					if fields[field_proto] then
						if fields.type=="table" then
						-- field 'cells' should contain a 2D table of cells, and
						-- field 'maxcols' indicates the number of columns to fill
							for y, row in ipairs(fields.cells) do
								for x=1, fields.maxcols do
									if x>colsFixed and x< fstCol2show then
										goto nextcolcell end
									if list_elem ~= "" then list_elem=list_elem.."," end
									if row[x]~=nil then
										list_elem = list_elem..minetest.formspec_escape(tostring(row[x]))
									else
										list_elem = list_elem..""
									end
									::nextcolcell::
								end
							end						
						else
							for i, elem in ipairs(fields[field_proto]) do
								if field_proto=="captions" and fields.captions_related_level~=nil then
								-- we have a tabheader fields, add caption only if related_level ok:
									if fields.captions_related_level[fields.captions[i]]
									:find(shape_me.players[pname].priv)==nil then goto nextelem end
								end
								if list_elem ~= "" then list_elem=list_elem.."," end
								list_elem = list_elem..minetest.formspec_escape(tostring(elem))
								::nextelem::
							end	
						end
					else
					-- here should be an error to manage : we need a list of elements expected in
					-- fields[field_proto] but it is nil, so the list of elements is empty.
					minetest.log("mod shape_me ERROR in init.lua:make_formspec():process_fields() :\n"..
						"player name = "..pname..";\n"..
						"element parsed = "..element.." of type '"..fields.type.."';\n"..
						"field searched = "..field_proto.." which is a table,\n"..
						"but there is no such field in this element.")
					minetest.chat_send_player(pname,"Mod Shape_me error while making form."..
						"Please see debug.txt log (search string 'init.lua:make_formspec():"..
						"process_fields()') for more informations.\n"..
						"Form may not be shown correctly as you will have an empty list for element"..element)
					end
					formated_string = formated_string..list_elem
				else
					-- fields contain the field 'field_proto' we are looking for, which is not a list :
					-- example : fields={x=1, y=2, w=4, ... label="MyLabel"}
					if fields[field_proto]~=nil then
						t = type(fields[field_proto])
						if t=="boolean" then
							formated_string = formated_string..tostring(fields[field_proto])
						else
							formated_string = formated_string..
								minetest.formspec_escape(fields[field_proto])
						end
					else
						-- this happen when fields do not contain the field field_proto :
						-- this can happen when searching for field "name" which is store in
						-- the parameter 'element' :
						if field_proto=="name" then
							formated_string = formated_string..element -- which is the name
						else
						--[[ Error to manage : we want to export the 'field_proto' field but it is
							not present in fields. That might produce a corrupted formspec's string...
							for example the field 'x' is missing for a 'label' element :(
							]]
						minetest.log("mod shape_me ERROR in init.lua:make_formspec():process_fields() :\n"..
							"player name = "..pname..";\n"..
							"element parsed = "..element.." of type '"..fields.type.."';\n"..
							"field searched = "..field_proto.." is not present in this element.")
						minetest.chat_send_player(pname,"Mod Shape_me error while making form."..
							"Please see debug.txt log (search string 'init.lua:make_formspec():"..
							"process_fields()') for more informations.\n"..
							"Form may not be shown correctly as field '"..field_proto..
							"' don't exist for element "..element.." of type "..fields.type)
						end
					end
				end
				field_num = field_num + 1
			end
			-- remove the last separator if value was nil :
			while string.find(",;",formated_string:sub(-1)) do
				formated_string = formated_string:sub(1,-2)
			end
			return formated_string
		end
	
		-- form contain the formspec definition researched; make a string :
		local form_str = ""
		if form.size==nil then return false, "size missing" end		
		form_str = "size["..form.size.w..","..form.size.h.."]\n"

		local fields2process
		local nb_fields -- for debug 
		local set_num	-- for iterating table of set of optionals fields
		local field_proto 
		local opt
		local priv = shape_me.players[pname].priv or "none"
	
		for element, fields in pairs(form) do
		-- element can be "label", "textarea", "tabheader", etc.
		-- fields refers to the element and can be "x","y","w","h","name","label", etc.
			if fields.type==nil then goto nextelement end -- not to be shown
			if element =="size" then goto nextelement end -- 1st taken in account;
			-- add only fields for the page 'page' or to be shown for all the pages (field page==nil)
			if fields.page~=nil and tostring(fields.page)~=tostring(page) then goto nextelement end
			-- do not add element if related_level exist and is higher than the player's privilege :
			if fields.related_level~=nil then
				if string.find(fields.related_level, priv)==nil then goto nextelement end
			end
			-- get the list of fields to export for this type:
			fields2process = forms.fields2export[fields.type]
			
			if fields2process then
				--[[ fields2process contain now the definition of the fields of element that 
				have to be exported.
				for example :
				fields2process = {					
			 		fields= {1="x", 2=",y", 3=";w", 4=",h", 5=";name", 6=";listelem{}"},
					fields_optional= {1= ";selected idx", 2=";transparent"}} 				
				]]
				form_str = form_str..process_fields(element, fields, fields2process.fields, false)
				--[[ parse now the fields_optional :
					may contain :
					1�) nil : no optional field;
					2�) numeric index = field prototype (separator, field's name, list marker)
						e.g. fields_optional= {1=";selected idx", 2 = ";list{}"}
				]]
				if fields2process.fields_optional then
					form_str = form_str..process_fields(element, fields, fields2process.fields_optional, true)
				end			
				
			end
			form_str = form_str.."]\n"
			::nextelement::
		end
		-- form_str = minetest.formspec_escape(form_str)
		shape_me.mydebug("log","the formspec had been formated in the string :\n"..form_str)
		shape_me.mydebug("log","shape_me.players="..dump(shape_me.players[pname]))
		return form_str
	end,
	summarize = function(pname) --[[ prepare explain text to show to the player about what can be
		done with the clicked block.
		explaination will be save with the form intended for player 'pname' ]]
		local msg -- build explanations
		local level = shape_me.players[pname].priv --[[ "user","controler" or "admin";
			note if player have no priv then .priv=="none" but this case won't happen here
			as it was check earlier in function 'registerer_tool_has_lclicked()'. ]]

		local def_update = {
				where_player_name 		= pname,
				where_element_name 		= "summary",
				update_fields 			= {}
			}
		--[[ the form must have an element named 'summary' to show the explanation text;
		this element of formspec can have element.type== "label" or "vertlabel", in which
		case we will store explanation in summary.label ; 
		else we will store explanation in summary.default, as for 
		summary.type== "field" or "textarea"  ]]
		local field = "default"
		if string.find(shape_me.players[pname].form.summary.type, "label") then field = "label" end
		local checks = shape_me.players[pname]
		
		msg = "You have clicked the block : "..checks.block.name..";\n"
		
		if checks.is_node==false then
			msg = msg.."there is nothing to do because\n"..
				"the clicked thing is not a node."				
			goto update
		end
		if checks.is_registered_node==false then
			msg = msg.."there is nothing to do because\n"..
				"the node clicked is not a registered node."
			goto update
		end
		if checks.is_drawtype_ok==false then
			msg = msg.."there is nothing to do because\n"..
				"the block "..checks.block.name..
				" is of drawtype \n"..checks.block.drawtype..
				" whitch is not suitable."
			goto update
		end
		if table.length(checks.mods2register) == 0 then
			msg = msg.."there is nothing to do because\n"..
				"there is no new mod to register this block;\n"			
			for k, v in pairs(checks.mods) do
				if v==true then
					msg = msg.."- mod "..k.." has already shaped it;\n"
				end
			end
			goto update
		end
		if checks.is_pending==true then
			msg = msg.."there is nothing to do because\n"..
				"this block is already hit and is now pending for\n"..
				"approval by accredited player."
			goto update
		end
		if checks.is_2process==true then
			msg = msg.."there is nothing to do because\n"..
				"this block is already registered to \n"..
				"be processed from next server restart."
			goto update
		end
		msg = msg.."it can be shaped by mods \n"
		for k, _ in pairs(checks.mods2register) do
			msg = msg.."- "..k..";\n"
		end
		msg = msg..
			"it will be registered to wait for approval by accredited player,\n"..
			"before to be processed at a later server restart."
		::update::
		def_update.update_fields[field] = msg
		forms.update_element(def_update)
		-- forms.save_to_file("summary")		
	end,
	prepare_pendings = function(pname) --[[ when the player had hit a block, feed 
		player.form.pendings
		with infos about mods to call for this block and others blocks which are waiting for approval
		we will build part of form to show as :
		form2show.pendings = {
			... others fields taken from 'summary' form;
			maxcols = 6, -- maxcols is usefull when making formspec, to complete rows with empty cells
			cells = {
				{2, "current block",   2, "mod #1"},
				{1, "pending block 1", 1, "mod #1", 1, "moreblocks"}, <- this line set maxcols to 6
				{2, "pending block 2"},
			}
			col_def = {
				[1] = {	type = "image",
						options = { [1] = "check_no.png", [2] = "check_yes.png" }},
				[2] = { type = "text" },
				[3] = {	type = "image",
						options = { [1] = "check_no.png", [2] = "check_yes.png" }},
				[4] = { type = "text" },
				[5] = {	type = "image",
						options = { [1] = "check_no.png", [2] = "check_yes.png" }},
				[6] = { type = "text" },
			}
		}
		take account of multiplayers server : the 1st player (with sufficient priv) which hit a block
		populate shape_me.pendings with a copy of file pendings, so we look first at existing 
		shape_me.pendings, after that at file pendings;
		when player update it's pendings copy (and validate pressing OK button), 
		update shape_me.pendings and update other players formspec if any;
		]]
		local tbldings -- shorter access for table_pending
		local hscrollb -- shorter for hscrollbar
		local imgdef = {
			type = "image",
			options = { [1] = "check_no.png", [2] = "check_yes.png", 
				["tooltip"] = "click to (dis)approve this option" }}
		local maxcols = 2
		local colnum = 0
		local rownum = 1
		local mod_num = 0
		
		-- init the formspec's representation of pendings :
		if shape_me.players[pname].form.pendings==nil then
			shape_me.players[pname].form.pendings = {}
			shape_me.players[pname].form.pendings = forms.content.summary.pendings
		end
		tbldings = shape_me.players[pname].form.pendings 
		hscrollb = shape_me.players[pname].form[tbldings.hscrollbar]
		local rowcell, coldef = {}, {}
		
		-- build formspec's pendings :
		if shape_me.players[pname].block==nil then goto addpendings end
		if shape_me.players[pname].mods2register==nil then goto addpendings end
		if table.length(shape_me.players[pname].mods2register)==0 then 
			goto addpendings 
		end
		-- add cells[row1] with data describing hit block's mods to call :
		if shape_me.players[pname].form.approve.selected==true then
			rowcell[1] = {2,shape_me.players[pname].block.name}
		else
			rowcell[1] = {1,shape_me.players[pname].block.name}
		end
		coldef[1] = imgdef
		coldef[2] = { type = "text" }
		mod_num = 1
		for k, _ in pairs(shape_me.players[pname].mods2register) do
			rowcell[1][(mod_num*2)+1] = 2
			rowcell[1][(mod_num*2)+2] = k
			coldef[(mod_num*2)+1] = imgdef
			coldef[(mod_num*2)+2] = { type = "text" }
			maxcols = maxcols+2
			mod_num = mod_num+1
		end
		::addpendings::
		-- add cells[rows] for all blocks already pending for approval :
		if table.length(shape_me.pendings)==0 then 
			shape_me.pendings = shape_me.load_datafile("pendings") 
		end
		local pendings = shape_me.pendings
		local modnum = 0
		local approve_all_blocks = false
		if shape_me.players[pname].form.approve_all ~= nil then
			if shape_me.players[pname].form.approve_all.selected == true then
				approve_all_blocks = true
			end
		end
		if table.length(pendings)==0 then goto endpendings end -- no block waiting for approval then skip
		for bname, params in pairs(pendings) do
			rownum = rownum+1
			if approve_all_blocks==true then
				rowcell[rownum] = {2, bname}
			elseif params.approved==true then
				rowcell[rownum] = {2, bname}
			else
				rowcell[rownum] = {1, bname}
			end
			coldef[1] = imgdef
			coldef[2] = { type = "text" }
			modnum = 0
			for mod, approved in pairs(pendings[bname].mods) do
				modnum = modnum+1
				if approved==true then
					rowcell[rownum][(modnum*2)+1] = 2
				else
					rowcell[rownum][(modnum*2)+1] = 1
				end
				rowcell[rownum][(modnum*2)+2] = mod
				if modnum>maxcols then
					coldef[(modnum*2)+1] = imgdef
					coldef[(modnum*2)+2] = { type = "text" }
					maxcols = maxcols+2
				end
			end
		end
			
		::endpendings::
		tbldings.maxcols = maxcols
		tbldings.cells = rowcell
		tbldings.col_def = coldef
		tbldings.hscrollbar = "hscrollbar"
		tbldings.slideBy = 2 -- number of columns to slide at once (1 for checkbox, 1 for name of mod)
		tbldings.colsFixed = 2 -- the 2 first columns dont slide and stay visible
		tbldings.cols2slide = maxcols - tbldings.colsFixed

		-- valPerCols is the amount of horizontal scrollbar's sliding per group (slideBy) of columns
		tbldings.valPerCols = (1000 / tbldings.cols2slide) * tbldings.slideBy
		-- fstCol2show is the n� of the 1st sliding column to show, after fixed columns, depending on
		-- the actual position of the H-scrollbar cursor
		tbldings.fstCol2show = tbldings.colsFixed+1+
						(math.floor(hscrollb.value/tbldings.valPerCols)*tbldings.slideBy)
		shape_me.players[pname].form.pendings = tbldings
	end,
	show_summary = function(pname, page)
		local str_form		
		if page==nil then page=1 end
		forms.summarize(pname) -- register explanations in the form
		forms.prepare_pendings(pname) -- set the table pendings (for approval)
		str_form = forms.make_formspec(pname, page)
		minetest.show_formspec(pname,"shape_me:summary",str_form)
		-- shape_me.mydebug("both", "player.form="..dump(shape_me.players[pname].form) ,pname)
	end,
}

forms.load_file("summary") -- for all players
if forms.content.summary==nil then forms.add_formspec(formspecs.summary, "summary", false) end
forms.save_to_file("summary")

forms.add_formspec({size = { --[[ add form "show_msg" when no privilege or no interact ]]
		type = "size",
		w=6, h=4},
	text_to_show = {
		type = "label",
		x = 0.5,	y = 0.5,
		label = "the text to be shown"},
	btn_exit = {
		type = "button_exit",
		x = 1,	y = 3,
		w = 2,	h = 1,
		label = "OK"},
	},
	"show_msg", false
)

local function show_msg(player_name, msg)
	msg = minetest.formspec_escape(msg)
	local str = "Nothing to do because \n"..msg
	local updated, reason
	
	updated, reason = forms.update_element(
			{where_form_name = "show_msg",
			where_element_name = "text_to_show",
			update_fields = {label = str} } )

	--shape_me.mydebug("log","function show_msg return "..tostring(updated).." : "..reason.."\n"..
	--	"dump(forms)="..dump(forms))
	str = forms.make_formspec("show_msg")
	shape_me.mydebug("both","will show formspec:"..str, player_name)
	minetest.show_formspec(player_name,"shape_me:nothing_todo",str)
end

-- define the functions for left-click with the intended tool :
local function registerer_tool_has_lclicked(player, pointed_thing)
	local pname -- the player name
	local level -- a string that represent both the higher privilege level and a part of
				-- the formspec's name to show
	local pt = pointed_thing
	local msg = "something to say to the player; nothing at this time."
	local node = minetest.get_node(pt.under)	-- the node hit

	pname = player:get_player_name()
	shape_me.mydebug("both","enter function register_tool_has_lclicked();", pname)
	do --[[ STEP #0 : init shape_me.players[pname] ]]
		shape_me.players.init(pname)		
		
-- ############## DEV time only : #########################################################	
--		forms.load_file("summary") -- developpment time only !!
-- ########################################################################################
		
		shape_me.players[pname].form = forms.content.summary
	end
	do --[[ STEP #1 : check the player privileges for shape_me, deny access if no priv : ]]
		level = shape_me.players.check_privs(pname) -- get "admin","controler","user" or "none"
		if level=="none" then
			show_msg(pname, "sorry "..pname..", but you haven't the necessary privilege to use this tool.")
			shape_me.players.clear(pname)
			return
		end
	end
	do --[[ STEP #2 : is it a node ? ]]
		shape_me.players[pname].is_node = (pointed_thing.type=="node")
		if shape_me.players[pname].is_node==false then goto call_form end
	end
	do --[[ STEP #3 : is it a registered node ? (it may be other thing, like mesh, entity or so) ]]
		shape_me.players[pname].is_registered_node = (minetest.registered_nodes[node.name]~=nil)
		if shape_me.players[pname].is_registered_node==false then
			goto call_form
		end
	end
	do --[[ STEP #4 : clone block for this player's action : ]]
		shape_me.players[pname].block = {}
		for k, v in pairs(minetest.registered_nodes[node.name])do
			shape_me.players[pname].block[k] = v
		end
	end
	do --[[ STEP #5 : is drawtype in allowed drawtypes ? ]]
		local block_dtype = shape_me.players[pname].block["drawtype"]
		if (block_dtype==nil) or (string.find(shape_me.settings.allowed_drawtypes(), block_dtype)) then 
			shape_me.players[pname].is_drawtype_ok = true
		else
			goto call_form
		end
	end
	do --[[ STEP #6 : add valuable fields to block def : ]]
		local sep = shape_me.players[pname].block.name:find(":")
		shape_me.players[pname].block.short_name = shape_me.players[pname].block.name:sub(sep+1) -- the name of the block not prefixed with it's mod name (example : "wood")
	
		if not shape_me.players[pname].block.groups then shape_me.players[pname].block["groups"]={oddly_breakable_by_hand=1} end
		if not shape_me.players[pname].block.sounds then shape_me.players[pname].block["sounds"]=default.node_sound_glass_defaults() end
	end
	do --[[ STEP #7 : is there at least 1 mod to shape this block ? : ]]
		shape_me.players.check_shaped(pname) --[[ check if the block was already processed and 
		by which mod; list in shape_me.players[pname].mods2register{} the mods-to-call that 
		havent already shaped this block :	]]
		shape_me.mydebug("log","shape_me:init(step7) : #shape_me.players[pname].mods2register="..
			tostring(table.length(shape_me.players[pname].mods2register)))
		if table.length(shape_me.players[pname].mods2register) == 0 then
			goto call_form
		end		
	end
	do --[[ STEP #8 : is this block already hit and waiting for approval ? : ]]
		shape_me.players.check_pending(pname) --[[ if yes, 
			shape_me.players[pname].is_pending is set to true ]]
		
		if shape_me.players[pname].is_pending==true then goto call_form end
	end
	do --[[ STEP #8b: is this block registered for next server restart ? : ]]
		if shape_me.players.check_2process(pname)==true then 
			shape_me.mydebug("both","check if block is to be processed = true",pname)
			goto call_form 
		end
	end
	do --[[ STEP #9 : prepare to register pending work (can be finaly 
			confirmed or canceled in mt.on_receive_fields) :]]	
		local bname = shape_me.players[pname].block.name			
		shape_me.players[pname].pending[bname] = {
			mods = {},
			player_name = pname,
			requested = os.time(),
			approved = false,
		}
		for k, _ in pairs(shape_me.players[pname].mods2register) do
			shape_me.players[pname].pending[bname].mods[k] = true
		end
	end
	
	::call_form::
	shape_me.mydebug("both", "shape_me.settings["..level.."_need_to_confirm]()="..
		tostring(shape_me.settings[level.."_need_to_confirm"]()), pname)
	if shape_me.settings[level.."_need_to_confirm"]()==true then
		forms.show_summary(pname)
	else
		-- here come code to register work as if it was confirmed by player :
		shape_me.mydebug("both","level "..level.." don't want confirm form. Do the job !",pname)
	end
end

-- register pending work when 'user' confirm his choice in order to enable 'controler' or
-- 'admin' to validate it
local function register_pending_work(pname)	
	
	local pendings
	local file, err_msg
	local bname
	
	if shape_me.players[pname].pending==nil then goto registerpendings end
	if shape_me.players[pname].pending=={} then goto registerpendings end
	
	-- copy pending block to pendings :
	bname = shape_me.players[player_name].block.name -- shorter for block.name
	shape_me.pendings[bname] = shape_me.players[pname].pending[bname]
	
	pendings = shape_me.load_datafile("pendings") -- load pendings from file pendings.dat
	if pendings==false then pendings = {} end

	pendings[bname] = shape_me.players[player_name].pending[bname] -- add pending block (or update)
	
	file, err_msg = shape_me.save_datafile("pendings", pendings) -- save to file
	if not file then
		minetest.log("shape_me error writing file pendings.dat\n"..
				"io error message : "..err_msg)
		return false
	end
	::registerpendings::
	return true
end

local function register_work_for_restart(pname)

	if shape_me.players[pname].pending==nil then return end
	if shape_me.players[pname].pending=={} then return end
	if shape_me.players[pname].pending.block_name==nil then return end
	if shape_me.players[pname].pending.block_name=="" then return end
	
	local filename = "blocks2process"
	local blocks2process = {}
	local process2add = {}
	local file, err_msg
	local bname = shape_me.players[pname].pending.block_name -- shorter for block name
	
	shape_me.mydebug("both", "register_work_for_restart()...",pname)
	do -- load blocks2process :
		blocks2process, err_msg = shape_me.load_datafile("blocks2process")
		if not blocks2process then blocks2process={} end
	end
	do -- add pending to process2add then to blocks2process :
		process2add[bname] = {			
			mods = nil,
			requested = {
				playername = shape_me.players[pname].pending[bname].player_name,
				request_date = shape_me.players[pname].pending[bname].requested },
			validated = {
				playername = pname,
				validate_on = os.time()	},
		}
		-- add mods to call only if approved :
		for mod, do_it in pairs(shape_me.players[pname].pending[bname].mods) do
			if do_it==true then
				if process2add[bname].mods==nil then process2add[bname].mods={} end
				process2add[bname].mods[mod] = true
			end
		end
		-- add to blocks2process only if there is at least 1 mod to call :
		if process2add[bname].mods~=nil then blocks2process[bname] = process2add[bname] end
	end
	do -- write blocks2process :
		file, err_msg = shape_me.save_datafile("blocks2process", blocks2process)
		if not file then
			minetest.log("shape_me error writing file blocks2process.dat\n"..
				"io error message : "..err_msg)
			return false
		end
		return true
	end
end

-- callback for leftclick after exit formspec:
minetest.register_on_player_receive_fields(function(player, formname, fields)
    -- Return true to stop other minetest.register_on_player_receive_fields
    -- from receiving this submission.
	local pname = player:get_player_name()
	local form_must_refresh = false
	local clear_player_form = false
	local current_tab = 1
    if formname== "shape_me:nothing_todo" then
		shape_me.mydebug("tchat", "shape_me : nothing was prepended to be done", pname)
		fields = nil
        return true
	elseif formname=="shape_me:test" then
		shape_me.mydebug("both","form test returned fields="..dump(fields),pname)
		if fields.btn_maj then
			rightclik_action(player, fields)
		end
		return true
    elseif formname== "shape_me:summary" then
		local fname = formname:sub(10) -- "summary"
		-- Send message to player.
		shape_me.mydebug("both","form summary return fields :"..dump(fields),pname)
		
		local msg=""
		local t -- shorter for : t=type(a_long_name)
		local def_update = {	-- structure to call forms.update_element(def_update)
			where_player_name = pname,
			where_element_name = "name of element", -- completed later on code
			update_fields = {"table of field=value to update"},
			add_missing_elem = false,
			add_missing_field = false,
		}
		local field_name = ""
		for field, value in pairs(fields) do
			if string.find("quit btn_maj proceed cancel", field) then goto parse_next_field end
			shape_me.mydebug("log","pname="..pname..", field="..field..
				", shape_me.players = "..dump(shape_me.players))
			-- prevent a bug : sometimes a first click on "cancel" set
			-- shape_me.players[pname] to nil but let the form shown to the player; 
			-- a second click will crash the server :/
			if shape_me.players[pname]==nil then break end
			if shape_me.players[pname].form[field]==nil then goto parse_next_field end
			t = shape_me.players[pname].form[field].type
			if t==nil then goto parse_next_field end
			if t == "label" then 		field_name = "label"
			elseif t=="field" then		field_name = "default"
			elseif t=="textarea" then	field_name = "default"
			elseif t=="checkbox" then 	field_name = "selected"
			elseif t=="tabheader" then 	field_name = "current_tab"
			end
			if field_name~="" then
				def_update.where_element_name = field
				def_update.update_fields = {[field_name] = value}
				forms.update_element(def_update)
				form_must_refresh = true
			elseif t=="table" then
				if field=="pendings" then -- action on table 'pendings' :
				-- value is smthing like CHG:<row>:<col>
					local happened = value:split(":")
					forms.toggle_tablecell(pname,field,happened[2],happened[3])
					form_must_refresh = true
				end
			elseif t=="scrollbar" and value.sub(1,3)~="VAL" then
				def_update.where_element_name = field
				def_update.update_fields = { ["value"] = tonumber(string.split(value,":")[2])}
				forms.update_element(def_update)
				if shape_me.players[pname].form[field].associated_table~=nil then
					forms.update_scrollable_table(pname, field)
					form_must_refresh = true
				end
			else
				shape_me.mydebug("both","To be implemented: field "..field..
				" of type "..t.." received value "..tostring(value).." from formspec shown.",pname)
			end	
			if field == "approve_all" then
			-- set checkboxes in pendings table like 'approve_all' :
				for i, _ in ipairs(shape_me.players[pname].form.pendings.cells) do
					if value=='true' then
						shape_me.players[pname].form.pendings.cells[i][1] = 2
					else
						shape_me.players[pname].form.pendings.cells[i][1] = 1
					end
				end
				form_must_refresh = true
			end
			::parse_next_field::
		end
		if form_must_refresh==true then
			minetest.show_formspec(pname,formname,
				forms.make_formspec(pname,shape_me.players[pname].form.tabheader.current_tab))
		end
		if fields.btn_maj=="refresh" then
			shape_me.mydebug("both","form summary will be reload from file.",pname)
			forms.load_file("summary")
			shape_me.players[pname].form = forms.content.summary
			local str = forms.make_formspec(pname,1)
			shape_me.mydebug("both","form summary will be show as string :"..str,pname)
			minetest.show_formspec(pname,formname,str)
		end
		if fields.proceed then
			-- update shape_me.pendings if needed :
			shape_me.mydebug("both","OK button pressed, proceed...",pname)
			if shape_me.players[pname].has_modified_pendings==true then
				shape_me.update_pendings(pname)
				shape_me.mydebug("both","pendings was modified, they are now updated",pname)
			end
			if minetest.is_yes(shape_me.players[pname].form.approve.selected)~=true then
				-- player dont checked option to skip validation step
				msg = "You confirmed the prepended work which is now waiting for validation by an accredited player"
				register_pending_work(pname)
			else
				msg = "the hit block will be processed at next server restart."
				register_work_for_restart(pname)
			end
			clear_player_form = true
			shape_me.mydebug("both","end of proceed case, player.form will be cleared.",pname)
			::endproceed::
		end
		if fields.cancel then
			msg = "You canceled the prepended work. Nothing will be done"
			clear_player_form = true
		end
		shape_me.mydebug("tchat", msg, pname)
		fields = nil
		if clear_player_form==true then
			shape_me.players[pname] = nil
		end
		-- if no other player is actually using the form, remove pendings table :
		-- shape_me.players[key] is not a player name :
		
		return true 
	else
		return false
	end
end)

minetest.register_craftitem("shape_me:registerer_tool",{
	description = "register hit block as processable by mods that shape blocks (circular saw, stairs, etc)",
	groups = {},
	inventory_image = "registerer_tool.png",
	wield_image = "registerer_tool.png",
	wield_scale = 1,

	stack_max = 1,
	liquids_pointable = true,
	--[[ function to handle right click :
	on_place = function(itemstack, placer, pointed_thing)
		shape_me.mydebug("tchat", "registerer tool right clicked", placer:get_player_name())
		rightclick()
		return itemstack
	end,
	]]
	-- function to handle left click :
	on_use = function(itemstack, user, pointed_thing)
		shape_me.mydebug("tchat", "shape_me:init:register_craftitem. registerer tool left clicked", user:get_player_name())
		registerer_tool_has_lclicked(user, pointed_thing)
		return itemstack
	end,
	
})

-- craft recipe for registerer tool :
minetest.register_craft({	
	output = "shape_me:registerer_tool",
	recipe = { {"stairs:stair_cobble"},
			   {"default:stick"},
			 }
})

--[[ for developpment stage : chatcommand dump and show formspec loaded from file :]]
minetest.register_chatcommand("dump", {
	params = "dump table",
	description = "dump table to chat",
	privs = {server = true},
	func = function( name , tbl)
		local subs = string.split(tbl,".",2)
		shape_me.mydebug("log","split "..tbl.." -> "..dump(subs))
		local main
		if table.getn(subs)==1 then
			main = _G[subs[1]]
		else
			main = _G[subs[1]][subs[2]]
		end
		
		minetest.chat_send_player(name, "Table "..tbl.." = "..dump(main))
		return true, "done."
	end })

minetest.register_chatcommand("form", {
	params = "test form",
	description = "test form",
	-- privs = {server = true},
	func = function( name , fname)
		local f = shape_me.check_dir(shape_me.files.root)..
				  shape_me.check_dir(shape_me.files.dir)..
				  fname..".txt"
		local file = io.open(f,"r")
		str = file:read("*all")
		file:close()
		-- str = minetest.formspec_escape(str)
		shape_me.mydebug("both","show form : \n"..str)
		minetest.show_formspec(name,"test",str)
		return true, str
	end })


shape_me.mydebug("log", "mod shape_me : init loaded.")