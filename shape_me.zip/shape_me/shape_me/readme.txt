Mod subnodes_registerer for minetest
By Tagada <tagacraft@free.fr>
april, 19th, 2018
Licence : MIT (see licence.txt in the mod's root folder)

Version :
=========
	0.1 - THE first version (cross fingers :) )

What the mod does :
===================
	in-game, register a block to be useable by the mods moreblocks (circular saw), stairs, and columnia; the block punched in-game with the intended tool will be transmited to the registration functions provided by the previous said 3 mods at the next server restart.

Restrictions :
==============
	the block to register MUST have a drawtype from:
	-none (normal drawtype)
	liquid
	glasslike
	glasslike_framed
	glasslike_framed_optional
	allfaces_optional
	other drawtypes are rejected (try to make a stair with a torch is not a good idea)


How to install :
================
	As others mods, just copy the whole folder/sub-folders in your minetest's mods folder.
Dependancies : 
==============
	only optional :
	stairs?
	moreblocks?
	columnia?

report bug, contact author :
=
===========================
	There is NO bug. 
	If you think otherwise, try :
	1�) call Chuck N. ... if he's not over the infinite;
	2�) tagacraft@free.fr if it still work;
	3�) github :
	and keep in mind the MIT licence allow you to modify the code as you want.
