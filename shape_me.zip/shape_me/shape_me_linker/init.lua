--[[ mod shape_me_linker by Tagada, 2018/05/08
		part of mod shape_me

aim to : write a file in world path containing parameters about some foreign mod that want
-------- to be called by the mod shape_me when a block is hit in game.
	then shape_me can read it at load time and deal with this file :
		- it add a line "mod_to_call?" in shape_me/depends.txt
		- Later, at run time, will be able to call the foreign mod's function.

location of datas :
-------------------
	Resulting of minetest core security mod, datas are writen in world path;
if a custom subfolder exist, use it, else
if a "shape_me" subfolder exist in world path, use it, else
use world path but then all data files created by shape_me will begin with "shape_me_";

so data files will be :
	<world_path> / <files_dir> / <file_name.dat>
or
	<world_path>"/shape_me_"<file_name.dat>
	
exception : file "shape_me_settings.txt" always stay in <world_path> to be read 
	at the begin of load time, when shape_me don't know yet if subfolder exist.
	
to use a custom subfolder name inside world path, in order to shape_me to use it as
data storage, you must :
- create yourself the directory;
- move the eventually existing shape_me's files (mask="shape_me_*.dat") into this folder, 
	EXCEPT the "shape_me_settings.txt" which MUST stay in <world_path>;
- update the setting : files_dir = your_custom_folder in <world_path>/shape_me_settings.txt file

]]

minetest.log("mod shape_me_linker begin init...")
-- Convert a lua table into a lua syntactically correct string
-- source : https://gist.github.com/justnom/9816256
function table_to_string(tbl)
    local result = "{"
    for k, v in pairs(tbl) do
        -- Check the key type (ignore any numerical keys - assume its an array)
        if type(k) == "string" then
            result = result.."[\""..k.."\"]".."="
        end

        -- Check the value type
        if type(v) == "table" then
            result = result..table_to_string(v)
        elseif type(v) == "boolean" then
            result = result..tostring(v)
        else
            result = result.."\""..v.."\""
        end
        result = result..","
    end
    -- Remove leading commas from the result
    if result ~= "" then
        result = result:sub(1, result:len()-1)
    end
    return result.."}"
end

-- receive a table rgb{r=redvalue, g=greenvalue, b=bluevalue} & return hexadecimal #RRGGBB
-- source : https://gist.github.com/marceloCodget/3862929
function rgbToHex(rgb)
	local hexadecimal = '#'

	for key, value in pairs(rgb) do
		local hex = ''

		while(value > 0)do
			local index = math.fmod(value, 16) + 1
			value = math.floor(value / 16)
			hex = string.sub('0123456789ABCDEF', index, index) .. hex			
		end

		if(string.len(hex) == 0)then
			hex = '00'

		elseif(string.len(hex) == 1)then
			hex = '0' .. hex
		end

		hexadecimal = hexadecimal .. hex
	end

	return hexadecimal
end

function table:length() -- return number of key indexes, numeric indexes in table
		--[[ example of returned values :
		if tbl={
			key_A = "something",
			[0] = "idx 0",
			[1] = "idx 1",
			[1.5] = "idx 1.5",
			[3] = function(params) end
		}
		table.length(tbl) will return 5, 1 because :
		about '5' : 
			the for.. pairs(tbl) will find all the indexes as keys, even if they are numeric;
		about '1' :
			the loop in ipairs(tbl) take in account only contiguous integers indexes from 1, so
			the numerics 0, 1.5 and 3 are considered as alphabetic keys while 0<1, 1.5 isnt an
			integer and the index '3' isn't contiguous to '1'.
			So only the numeric index '1' is taken in account as a numeric index.			
		]]
	local k = 0
	local i = 0
	for _, _ in pairs(self) do -- pairs count all indexes !
		k = k+1
	end
	for _, _ in ipairs(self) do -- ipairs count only contiguous integers from 1 !
		i = i+1
	end
	return k, i
end
-- context (for the 2 mods shape_me and shape_me_linker) :
shape_me = {
	_debug = true,		-- enable shape_me.mydebug() that do minetest.log and/or tchat
	mydebug = function(context, msg, playername)
		-- context may be 	"log" - then send msg to minetest.log;
		--					"tchat" - then send msg to minetest.chat_send_player;
		-- 					otherwise do nothing as if local debug_msg was false;
		if shape_me._debug~=true then return end		
		if context=="log" then 
			minetest.log(msg)
			return
		end
		if context=="tchat" then
			if playername~=nil then minetest.chat_send_player(playername, msg) end
			return
		end
		if context=="both" then
			minetest.log(msg)
			if playername~=nil then minetest.chat_send_player(playername, msg) end
		end
	end,
	settings = {
		default = {	-- explicitly numerical indexed to preserve order in settings.txt file
			[1] = { give_privs_to_server = true },
			[2] = { give_privs_to_single = true },
			[3] = { files_dir = "shape_me" },
			[4] = { not_in_creative_inventory = false },
			[5] = { admin_need_to_confirm = true }, -- if yes, show form to summarize hit consequences
			[6] = { admin_need_warnings = true }, -- show form to explain why nothing to do after hit
			[7] = { controler_need_to_confirm = true }, 
			[8] = { controler_need_warnings = true },
			[9] = { user_need_to_confirm = true }, -- 'true' highly recommended to avoid click-spam !
			[10] ={ user_need_warnings = true },-- 'true' highly recommended to avoid click-spam !
			[11] ={ allowed_drawtypes = "normal liquid glasslike glasslike_framed glasslike_framed_optional allfaces_optional"},
		},
		current = { --will be created at load time from default or data file
		},
		valueof = function(setting, value) --[[ set or return the value of a setting
				if value==nil, return the value for setting, or nil;
				else update setting with value or set it if setting doesn't exist yet, then
				return the numeric index of setting in settings.current{};
				if setting doesn't exist, create also get/setter function.
			]]
			local v=nil
			if value==nil then -- return the value			
				-- search in current :
				-- shape_me.mydebug("log","can we find "..setting.." in settings.current:"..dump(shape_me.settings.current).." ?")
				for i, set in ipairs(shape_me.settings.current) do
					if set[setting]~=nil then
						v = set[setting]
						-- shape_me.mydebug("log", setting.." found in current["..i.."]."..setting.." = "..tostring(v))
						break
					end					
				end
				if v==nil then -- testing 'if v' or 'if not v' doesn't work if v is boolean !
					-- shape_me.mydebug("log", "not found in current, search in default;")
					-- search default :
					for i, set in ipairs(shape_me.settings.default) do
						if set[setting]~=nil then
							v = set[setting]
							-- shape_me.mydebug("log", setting.." found in default["..i.."]."..setting.." = "..tostring(v))
							break
						end					
					end					
				end
				return v
			end
			do -- else set the value :
				local found = false
				v = 0			
				for i, set in ipairs(shape_me.settings.current) do
					v = i -- keep last numeric index in memory
					if set[setting]~=nil then
						set[setting] = value -- setting already defined : update it;	
						found = true
						break
					end					
				end
				if not found then -- setting not defined, add it :
					v = v+1
					shape_me.settings.current[v] = {}
					local str, func
					str = "shape_me.settings.current["..v.."]."..setting.." = "..value
					func = loadstring(str)
					func()
					-- add getter-setter function :
					str = "shape_me.settings."..setting.." = function(somevalue)"..
						" return shape_me.settings.valueof('"..setting.."', somevalue) end"
					func = loadstring(str)	
					func()
				end
				if setting=="files_dir" then shape_me.files.dir = value	end
				return v
			end
		end,
		load = function() -- load settings from <world_path> "/shape_me/settings.txt" to current
			local filename = minetest.get_worldpath().."/shape_me/settings.txt"
			local f, err = io.open(filename,"r")
			if not f then return nil, err end
			local i = 1
			local key, value, j
			for line in f:lines() do
				if line:sub(1,1)~="#" and line:find("=") then -- parse line key = value :
					j = line:find("=")
					key = line:sub(1,j-1)					
					value = line:sub(j+1)
					if key and value then -- trim key and value :
						while key:sub(1,1)   ==" " do key=key:sub(2) 		end
						while key:sub(-1,-1) ==" " do key=key:sub(1,-2) 	end
						while value:sub(1,1) ==" " do value=value:sub(2) 	end
						while value:sub(-1,-1)==" " do value=value:sub(1,-2) end
					end
				end
				if key and value then -- store in shape_me.settings[key] & shape_me.settings.current:
					i = shape_me.settings.valueof(key, value)
				end
			end
			f:close()
			return true
		end,		
		save = function(src) -- save src (default or current) into settings.txt
			local filename = minetest.get_worldpath().."/shape_me/settings.txt"
			local f, err = io.open(filename, "w")
			if not f then return nill, err end
			
			f:write("# mod shape_me, settings file :\n")
			f:write("# comment line are not implemented else those ones\n")
			f:write("#\n")
			f:write("# A setting must be alone on one line,\n"..
					"# writen like :\n"..
					"# setting = value\n")
			for i, v in ipairs(src) do
				for k, v2 in pairs(v) do
					f:write(k.." = ")
					if type(v2)=="string" then
						f:write("\""..v2.."\"")
					elseif type(v2)=="table" then
						f:write(table_to_string(v2))
					else
						f:write(tostring(v2))
					end
					f:write("\n")
				end
			end			
			f:close()
			return true
		end,		
		--[[ below, getter-setter functions will be dynamically created at load time from
		effective settings loaded from data file settings.txt or default :
		give_privs_to_server = function(value) return shape_me.settings.valueof("give_privs_to_server",value) end,
		give_privs_to_single = function(value) return shape_me.settings.valueof("give_privs_to_single",value) end,
		not_in_creative_inventory = function(value) return shape_me.settings.valueof("not_in_creative_inventory",value) end,
		files_dir = function(value) return shape_me.settings.valueof("files_dir", value) end,
		for example :
		shape_me.settings.give_privs_to_server() will return the value of give_privs_to_server, or nill;
		shape_me.settings.give_privs_to_server(a_new_value) will set it to a_new_value.
		Any setting founded in the file <world_path>/shape_me/settings.txt will do the same.
		]]
	},
	radical = "shape_me", -- used when no custom world-path subfolder
	files = {
		root = minetest.get_worldpath(),
		dir  = "",		-- DO NOT EDIT : will be "shape_me" if mkdir(world_path/shape_me) success
		prefix = "",	-- if 'dir' failed, will be set to "shape_me_" to group files into world_path
	},
	check_dir = function(path) -- add "/" ending path if needed and return it
		if path:sub(-1)~= "/" and path:sub(-1)~="\\" and path~="" then
			return path.."/"
		else
			return path
		end
	end,
	test_dir = function(path) -- return true if path exist inside world path :
		local paths = minetest.get_dir_list(shape_me.files.root,true)
		if table.getn(paths)==0 then return false end
		for _, a_path in ipairs(paths) do
			if a_path == path then return true end
		end
		return false
	end,
	mods2call = { -- default minimal content for mods2call file :
		moreblocks = {
			{ func_name = "stairsplus:register_all",
			parameters = {
				--[[ value_type can be 
					- "field" : value contain the name of a field of block,
					- "nostring" : value contain the name of an object (like a function, table, ..)
						that will not be surrounded with quotes,
					- "string" : value contain a string to surround with quotes	
				  plus :
					a parameter is a table of a "value_type={}" and a "value={}" tables;
					both must have the same number of entries, like :
					value_type={"t1","t2","t3"} and value={"v1","v2","v3"};
					so i will use this to concatenate v1..v2..v3 depending on the type of each value,
					as described by "t1", "t2" and "t3"
				]]
				{value_type = {"field"}, value = {"mod_origin"}},
				{value_type = {"field"}, value = {"short_name"}},
				{value_type = {"field"}, value = {"name"}},
				{value_type = {"field"}, value = {"fields"}},
				}
			},
			{ func_name = "table.insert",
			parameters = {
				{value_type = {"nostring"}, value = {"circular_saw.known_stairs"}},
				{value_type = {"field"},  value = {"name"}},
				}
			},
			add_missing_fields = true,
			add_missing_rules = {never={types={"function"}}},			
			typical_derivated = { -- will be used to check if a full block is already derivated by this mod
				field_to_check = "name",
				content = {
					{value_type = {"string", "field"}, value = {"moreblock:slope_", "short_name"}},
					{value_type = {"field","string","field"}, value = {"mod_origin", ":slope_", "short_name"}},
				}
			}
		},
		stairs = {
			{ func_name = "stairs.register_stair_and_slab",
			parameters = {
				{value_type = {"field"}, value = {"short_name"}},
				{value_type = {"field"}, value = {"name"}},
				{value_type = {"field"}, value = {"groups"}},
				{value_type = {"field"}, value = {"tiles"}},
				{value_type = {"field","string"}, value = {"description"," stair"}},
				{value_type = {"field","string"}, value = {"description"," slab"}},
				{value_type = {"field"}, value = {"sounds"}},
				},
			},
			add_missing_fields = true,
	-- add_missing_rules is not said, so it will be nil and then replaced by default rule (no function)
			typical_derivated = { -- will be used to check if a full block is already derivated by this mod
				field_to_check = "name",
				content = {
					{value_type = {"string", "field"}, value = {"stairs:stair_", "short_name"}},
				}
			}
		},
		columnia = {
			{ func_name = "register_column_ia",
			parameters = {
				{value_type = {"field"}, value = {"short_name"}},
				{value_type = {"field"}, value = {"name"}},
				{value_type = {"field"}, value = {"groups"}},
				{value_type = {"field"}, value = {"tiles"}},
				{value_type = {"field","string"}, value = {"description"," Column"}},
				{value_type = {"field","string"}, value = {"description"," Column Top"}},
				{value_type = {"field","string"}, value = {"description"," Column Bottom"}},
				{value_type = {"field","string"}, value = {"description"," Column Crosslink"}},
				{value_type = {"field","string"}, value = {"description"," Column Link"}},
				{value_type = {"field","string"}, value = {"description"," Column Linkdown"}},
				{value_type = {"field"}, value = {"sounds"}},
			},
			},
			add_missing_fields = true,
			typical_derivated = { -- will be used to check if a full block is already derivated by this mod
				field_to_check = "description",
				content = {
					{value_type = {"field","string"}, value = {"description", "Column"}},
				}
			},
		}
	},
	test_rules_for_blockfield = function(block, k, rules) -- WIP : is block[k] ok with rules ?
		-- to be implemented !
		if type(block[k])=="function" and
		rules == {never={types={"function"}}} then
			-- shape_me.mydebug("log","field "..k.. "(type function) will not be added")
			return false
		end
		return true
	end,
	players = { -- list of players whitch are actually using the shape_me tool
		singleplayer = { -- a name of a player (re-init each time player hit a block)
			block = {},	
			mods = {	-- list of mods whitch have already shaped (true) or not (false) the block :
				modname1 = false,
				modname2 = false,
			},
			mods2register = { -- list of mods that is still able to shape this block
				modname1 = true,
				modname2 = true,
			}, 
			priv = "none", -- set by check_privs() at none, user, controler or admin
			pending = { -- block hit & waiting for player's confirmation's formspec
				bname = { -- the name of a block (i.e. 'default:dirt')
					mods = {},
					player_name = "",
					requested = os.time(),
					approved = false, -- will be set to true if player confirm his choice
				},
			},
			has_modified_pendings = false, -- become true when player click in form.pendings table
			is_node = false, -- true if clicked thing is of type "node"
			is_registered_node = false, -- true if in minetest.registered_nodes[]
			is_drawtype_ok = false,
			is_pending = false,  -- if set to true by check_pending(), block has already been hit
			is_2process = false, -- if registered in blocks2process.dat file for next restart
			form = {}, -- copy of "summary" with specific infos for this player			
		},
		init = function(pname)
			shape_me.players[pname] = {
				block = {}, 			-- hit-block's def (=registered_nodes[block name])
				mods = {}, 			--[[ list of mods registered to be call :
					mods = {mod#1 = boolean, ...} : true if has already shaped this block, else false; ]]
				mods2register = {}, -- list of above mods set to 'false'
				priv = "none", -- highest shape_me priv granted to this player
				pending = {}, -- formated infos for this block to insert in pendings.dat file
				has_modified_pendings = false, -- true when click in pendings table
				is_node = false, -- the hit thing is a node
				is_registered_node = false, -- hit thing is a minetest.registered_nodes[]
				is_drawtype_ok = false,
				is_pending = false, -- hit block already pending for approval
				is_2process = false, -- already registered in blocks-to-process at server start ?
				form = {},
			}
		end,
		clear = function(pname)
			shape_me.players[pname] = nil
		end,
		check_privs = function(pname) -- called when player pname hit a block
			local privs = minetest.get_player_privs(pname)
			shape_me.players[pname].priv = "none"
			if privs.shape_me_user then 	 shape_me.players[pname].priv = "user" 		end
			if privs.shape_me_controler then shape_me.players[pname].priv = "controler" end
			if privs.shape_me_admin then 	 shape_me.players[pname].priv = "admin" 	end
			return shape_me.players[pname].priv
		end,
		check_shaped = function(pname) -- check if block hit by player pname is already shaped
			--[[ this function is called when a player hit a block, so
				players[pname].block is already filled ]]
			shape_me.players[pname].mods = {}
			for k, v in pairs(shape_me.mods2call) do 
				shape_me.players[pname].mods[k] = false 
			end
			shape_me.players[pname].mods2register = {}
			local a_block = shape_me.players[pname].block
			local look_at ="" -- content to search
			local found = false -- content is found or not
			for k, v in pairs(shape_me.mods2call) do --[[ for each mod to call :
				if typical_derivated==nil then just look at next mod : we can't know if this
				mod has already processed this block so this mod will be called for this block. ]]
			
				if v.typical_derivated~=nil then -- construct the content to look for :
					for ci, cv in ipairs(v.typical_derivated.content) do
						look_at = ""
						for vi, vv in ipairs(cv.value_type) do
							if vv=="string" then look_at = look_at..cv.value[vi] end
							if vv=="field" then look_at = look_at..tostring(a_block[cv.value[vi]]) end
						end
						if v.typical_derivated.field_to_check == "name" then
							if minetest.registered_nodes[look_at] then
								shape_me.players[pname].mods[k] = true
								found = true
								break
							end
						else -- the field to check is not "name" : search in all nodes :
							for k2, v2 in pairs(minetest.registered_nodes) do
								if v2[v.typical_derivated.field_to_check] == look_at then
									shape_me.players[pname].mods[k] = true
									found = true
									break
								end
							end
						end
						if found==true then break end
					end
				end
				if found==false then
					shape_me.players[pname].mods2register[k]=true
				end
			end
			shape_me.mydebug("log","table.length(shape_me.players[pname].mods2register) = "..
				tostring(table.length(shape_me.players[pname].mods2register)))
			return (table.length(shape_me.players[pname].mods2register) > 0)
		end,
		check_2process = function(pname) -- check if block hit is registered for next restart;
			-- check also if there is at least 1 mod that isn't registered to shape this block
			shape_me.mydebug("log","? is "..shape_me.players[pname].block.name..
				" in list to process ?")
			shape_me.players[pname].is_2process = false
			if table.length(shape_me.blocks2process)==0 then
				shape_me.players[pname].is_2process = false
				shape_me.mydebug("log","no (not any block to process)")
				return false
			end
			local bname = shape_me.players[pname].block.name
			if shape_me.blocks2process[bname]~=nil then			
				-- block is in list to be processed, but is there some mods not yet registered ?
				shape_me.players[pname].is_2process = true
				shape_me.mydebug("log","yes, found in list.")
				for k, _ in pairs(shape_me.mods2call) do
					if shape_me.blocks2process[bname].mods[k]==nil then
					-- mod 'k' is not yet registered to process this block : add it!
						shape_me.players[pname].mods2register[k] = true
						shape_me.players[pname].is_2process = false
						shape_me.mydebug("log","but some mods can still register it.")
					end
				end				
			else
				shape_me.mydebug("log","no, not found in list.")
			end
			return shape_me.players[pname].is_2process
		end,
		check_pending = function(pname)
			shape_me.players[pname].is_pending = false
			if table.length(shape_me.pendings)==0 then return false end
			if shape_me.pendings[shape_me.players[pname].block.name] then
				shape_me.players[pname].is_pending = true
			end			
			return shape_me.players[pname].is_pending
		end,
	},	
	load_datafile = function(fname) -- return file ...<fname>.dat
		if type(fname)~="string" then return false, "in shape_me:load_datafile(fname), fname was not a string." end
		
		local filename = shape_me.check_dir(shape_me.files.root)..
						shape_me.check_dir(shape_me.files.dir)..
						shape_me.files.prefix..fname..".dat"
		local file, err_msg = io.open(filename, "r")
		local ftable -- a table with the file's content
		if not file then return false, err_msg end -- no <fname>.dat file
		ftable = minetest.deserialize(file:read("*all"))
		file:close()
		return ftable
	end,
	save_datafile = function(fname, ftable) --[[ save table ftable into file <fname>.dat
		in a format human-readable and compatible with mt.deserialize() ]]
		if type(fname)~="string" then return false,
			"in shape_me:save_datafile(fname, ftable), fname was not a string." end
		if ftable==nil then ftable="" end -- will store an empty file

		local filename = shape_me.check_dir(shape_me.files.root)..
						shape_me.check_dir(shape_me.files.dir)..
						shape_me.files.prefix..fname..".dat"
		local file, err_msg = io.open(filename, "w")
		if not file then return false, err_msg end -- unable to write
		file:write("return "..dump(ftable))
		file:close()
		return true
	end,
	pendings = { --[[ will contain file 'pendings.dat' and updates currently mades by players
		content example :
		default:dirt = { -- the name of a block 
			mods = {
				moreblocks = true, -- the mod is prepended to be called for this block (if block is approved)
				stairs = true},
			player_name = "Example content",
			requested = os.time(),
			approved = false, -- for the moment, the block isn't approved to be processed
		},
		next_pending_block = {...}  ]]	
	},
	blocks2process = { --[[ will contain file 'blocks2process.dat' ]]
	},
	update_pendings = function(pname) --[[ when player 'pname' click on 'proceed' button in 
		formspec 'summary', this function is called if player :
		- have priv > 'user' and has modified the form.pendings.cells;
		
		so we have to :
		- update shape_me.pendings with values from player.form.pendings :
			- disapproved (uncheck) blocks are removed from list (if intended option is check in form);
			- approved blocks are cut+copy from pendings to file blocks2process;
			
		- if another player is also currently modifying shape_me.pendings, warn this player
	]]
		local form = shape_me.players[pname].form
		local tpendings = form.pendings.cells
		local bname, mname
		local nb_approved_mods
		local nb_mods
		local bupdated, mupdated = 0, 0 -- blocks updated, mods updated
		local mcheck -- true if mod is checked, false if not
		local something_changed = false
		local block2process = {}
		local blocks2process = shape_me.load_datafile("blocks2process")
		local source={}		
		local nb_keys, nb_cols
		
		if blocks2process==false then blocks2process = {} end
		for i, row in ipairs(tpendings) do
			bname = row[2]
			if row[1]==1 then -- remove this disapproved block from list (if option checked) :
				if form.remove_disapproved~=nil then
					if form.remove_disapproved.selected==true then
						shape_me.pendings[bname] = nil
						goto nextpending
					end
				end
			end
			nb_keys, nb_cols = table.length(row)
			mupdated = 0
			for j= 3, nb_cols, 2 do				
				mname = row[j+1]
				mcheck = (row[j]==2)
				if shape_me.pendings[bname]~=nil and
				   shape_me.pendings[bname].mods[mname]~=mcheck then
					shape_me.pendings[bname].mods[mname] = mcheck
					mupdated = mupdated +1
					something_changed = true
				end
			end
			-- transfert pending in blocks2process :
			block2process.approved = true
			if i==1 then 
				source = shape_me.players[pname].pending[bname]
			else
				source = shape_me.pendings[bname]
			end
			block2process.mods = source.mods
			block2process.requested = {
				playername = source.player_name,
				request_date = source.requested
			}
			block2process.validated = {
				playername = pname,
				validate_on = os.time()
			}
			blocks2process[bname] = block2process
			-- remove from pendings :
			shape_me.pendings[bname] = nil
			::nextpending::
		end
		-- rewrite blocks2process to file :
		shape_me.save_datafile("blocks2process",blocks2process)
		
	end,
}

do --[[ dvp tests ]]
	local tbl = {
		keyA = "a",
		keyB = "b"
	}
	shape_me.mydebug("log","#tbl="..#tbl.."\n table.length(tbl)="..tostring(table.length(tbl)))
end
do --[[ check first launch after install, create dir world_path/shape_me. ]]

	local basepath = shape_me.check_dir(minetest.get_worldpath()).."/shape_me"
	minetest.mkdir(basepath)
	local files = minetest.get_dir_list(basepath)
	if table.getn(files)==0 then
		shape_me.first_launch = true -- not used at this time
	end
	
end

do --[[ load settings file :
	first, try to read shape_me\settings.txt in world path :
	if unable, write settings from shape_me.settings.default into 
	<world path>"shape_me/settings.txt";
	then, load shape_me/settings.txt into shape_me.settings.current;
]]
	-- shape_me.mydebug("log", "shape_me_linker : loading setting file...")
	local st = shape_me.settings.load()
	local err_msg
	if not st then --[[ load from file failed, 
						write file settings.txt from shape_me.settings.default : ]]
		st, err_msg = shape_me.settings.save(shape_me.settings.default)
		if not st then -- failed to save default to file, take default as current
			minetest.log("Mod shape_me error writing default settings. io error ="..
				err_msg.."\n take defaults as current settings.")
			for i, v in ipairs(shape_me.settings.default) do
				for setting, value in pairs(v) do
					shape_me.settings.valueof(setting, value)
				end
			end
		else
			--[[ default was written into file settings.txt; reload it as
			it also set current setting values AND create getter_setter functions :]]
			st = shape_me.settings.load()
		end
	end		
end
	-- set files.dir accordingly to settings :
shape_me.files.dir = shape_me.settings.valueof("files_dir") or ""
do --[[ try to find a <world path><shape_me> folder, else 
		<world path>;
		set shape_me.files.prefix :
	]]
	if shape_me.files.dir~="" then -- files_dir is customized : does this folder exist ? 
		if not shape_me.test_dir(shape_me.files.dir) then -- custom files_dir is not valid
			shape_me.files.dir = ""
			shape_me.settings.valueof("files_dir", "") -- update settings
		end
	end
	if shape_me.files.dir=="" then
		shape_me.files.prefix = shape_me.radical.."_"
	else
		shape_me.files.prefix = ""
	end
end
do -- check if mods2call.dat exist and write the default one if not :
	local fname = "mods2call"
	local file_mods2call, err_msg = shape_me.load_datafile(fname)
	if not file_mods2call then -- file not exist, write the default one :
		file_mods2call, err_msg = shape_me.save_datafile(fname, shape_me.mods2call)
		if not file_mods2call then
			minetest.log("shape_me_linker error accessing file 'mods2call'. io.open error message :\n"..
				err_msg)
			minetest.log("shape_me will use defaults mods to call until a mods2call file exist.")
		end
	end
end
do --[[ check if blocks2process file exist and create a default one if not :
	read blocks2process.dat file and process blocks that have been validated by accredited player :
	by the time, this table will accumulate all the blocks to register with concerned mods per block

	each line of the file contain a definition for one full block
	the first time this mod is used, file blocks2process.dat contain the following table 
	(as example and minimal content) :
	]]
	-- local file_blocks2process
	local blocks2process = {	-- default minimal content
		["default:dirt_with_grass"] = {			-- the full block to register with some mods
			approved = true,
			mods = {									-- the mods to call to register the full block
				stairs = true,							-- true/false pending was validated
				moreblocks = true},			
			requested = {								
				playername = "MinimalContent",			-- whitch player had request that action
				request_date = os.time(),				-- at what date-time
			},
			validated = {								
				playername = "server",					-- which player validated the request
				validate_on= os.time(),					-- at what date-time
			},
		},
		["default:mese"] = {					-- next full block to process
			approved = true,
			mods = {
				stairs = true,
				moreblocks = true,
				columnia = true},
			requested = {
				playername = "MinimalContent",
				request_date= os.time(),			
			},
			validated = {
				playername = "server",
				validate_on = os.time(),
			},
		},	
	}

	local fname = "blocks2process"
	local result, err_msg
	shape_me.blocks2process = shape_me.load_datafile(fname) -- test if file exist :
	if shape_me.blocks2process == false then -- file does not exist yet, write default one :
		result, err_msg = shape_me.save_datafile(fname, blocks2process)
		if result==false then
			minetest.log("shape_me : error writing default file for blocks to process :\n"..
				"io error message = "..err_msg.."\n mod shape_me will be unable to run.")
			shape_me = nil
			return false -- unable to run shape_me :/
		end
		-- as loading from file has failed, transfert default blocks2process into shape_me :
		shape_me.blocks2process = blocks2process
	end
end

function register_me(mod_name, parameters) -- other mods call this to be registered by shape_me
--[[ - note for Core Mod security : when a foreign mod call register_me(foreign_mod_name),
			the io functions are granted only to world path and to foreign mod's path 
			but not to shape_me mod path.
	parameters expected :
	- mod_name : string containing the name of the mod whitch is calling register_me,
			e.g.: "moreblocks"
	- parameters : a table describing what is needed by the foreign function to call :
	{ {	func_name = "the_name_of_the_function#1_to_call",
		parameters = {  -- describe the parameters needed by the function :
			{value_type* = {"field",...}, value = {"the_name_of_a_node_def's_field",...}},
			{another parameter},
			{...}
		}
		add_missing_fields = true (or false), -- optional
		add_missing_rules = {never={types={"function"}}} -- optional
	  },
	  { func_name = "the next function to call",
	  ...
	  },
		typical_derivated = {	-- optional but highly recommended : used to check if a block 
			-- is already processed by the foreign mod; if unable to check, the foreign function
			-- will be called anyway, using resources.
			field_to_check = "the name of a field in block def",
			content = {
				{value_type* = {"string", ...}, value = {"a_string", ...}},
				{another parameter},
				{...},
			}
		}	
	}
	Explanations :
	--------------
		with those datas, shape_me will call "func_name(parameter#1..parameter#n)"
		as expected by this foreign function, plus perform suitables actions.
		
		parameters is a table of { param#1, param#2, ... ,param#n }
		param#1..n is a table of { value_type, value }
			the field "value_type" indicates what type of data is inside the field "value"
			value_type can contain "field", "string", or "nostring", and
			value_type can be a table made of the 3 previous strings, e.g: {"field","string","field",...}
			
			value contain data described by value_type, so if "value_type" is 
			a table of 2 elements then value MUST have the corresponding 2 elements.
			
			if value_type=="field", we add the content of the field (named in "value") from node's def;
			if value_type=="string", we add the string provided by "value", surrounded by quotes;
			if value_type=="nostring", we add the content of "value" without quotes;
			
		Suitables actions feasible :
		assuming func_name() created some new blocks shaped from a block provided in parameters,
		we can check if those new blocks inherited all the fields from their ancestor.
		As example, actualy, stairs loose the light of the ancestor because the field "source_light" 
		is lost in the minetest.register_node process made by stairs:register_stair()
		
		so the other parameters are :
		add_missing_fields : boolean. if true, add missing fields in new blocks, from their ancestor;
		add_missing_rules : a table of rules to select the types of fields to add or not.
			if set, at this time, only 1 case is taken in account, as :
			add_missing_rules = {never={types={"function"}}}
			that say : don't add a missing field if it is of type=="function"
		typical_derivated : a table that describe the rules to find, in minetest.registered_nodes, 
			a new block among all those created by func_name(). 
			The most often, the field "name" is constructed derivating the ancestor's name 
			e.g: default:dirt -> stairs:stair_dirt
			field_to_check : any valid name of a field in a node_def, like "tile", "groups", etc.
				plus few available fields names :
					- "fields" : all fields in one table;
					- "short_name" : node's name minus it's mod name (e.g: "dirt", without "default:")
					
		
	example for moreblocks, registering a block for circular saw :
	we must call 2 functions : stairsplus:register_all and table.insert :
	{ 
	  { func_name = "stairsplus:register_all",
		parameters = {
			{value_type = {"field"}, value = {"mod_origin"}},
			{value_type = {"field"}, value = {"short_name"}},
			{value_type = {"field"}, value = {"name"}},
			{value_type = {"field"}, value = {"fields"}},
			},
		add_missing_fields = true,
		add_missing_rules = {never={types={"function"}}}
		},
		{ func_name = "table.insert",
		parameters = {
			{value_type = {"nostring"}, value = {"circular_saw.known_stairs"}},
			{value_type = {"field"},  value = {"name"}},
			}
		},
		typical_derivated = { -- will be used to check if a full block is already derivated by this mod
			field_to_check = "name",
			content = {
				{value_type = {"string", "field"}, value = {"moreblock:slope_", "short_name"}},
				{value_type = {"field","string","field"}, value = {"mod_origin", ":slope_", "short_name"}},
			}
		}	
	}
	with those infos we construct :
	1°) stairsplus:register_all("default","dirt","default:dirt",{table of default:dirt's fields})
	2°) table.insert(circular_saw.known_stairs,"default:dirt")
	and we will check if exist a "moreblocks:slope_dirt" or a "default:slope_dirt" in whitch 
	case we will not call the moreblocks's functions.
]]
	local file, err_msg, result, a_func	
	local mods2call={}
	local fname = ""
	
	do -- some firsts checks for available parameters :
		if type(mod_name)~="string" then
			minetest.log("MOD shape_me_linker:register_me error : mod_name was of type "..
				type(mod_name)..", but string was expected")
			return false, "mod_name invalid : string expected, got "..type(mod_name)
		end
		if type(parameters)~="table" then
			minetest.log("MOD shape_me_linker:register_me error : parameters was not valid")
			return false, "parameters must be a table"
		end
		a_func = parameters[1]
		if type(a_func.func_name)~="string" or type(a_func.parameters)~="table" then
			minetest.log("shape_me_linker:register_me() error in parameters : see documentation for valid parameters")
			return false, "invalid parameters."
		end
	end
	
	-- load the file mods2call if exist, add new mod if not yet else update, rewrite file :
	fname = 	shape_me.check_dir(shape_me.files.root)..
				shape_me.check_dir(shape_me.files.dir)..
				shape_me.files.prefix .. "mods2call.dat"
	file, err_msg = io.open(fname, "r")
	
	if file then -- load file if exist :
		mods2call = minetest.deserialize(file:read("*all"))
		file:close()
	end	
	
--[[ TODO : verify all the components of "parameters" before update structure...]]	

	mods2call[mod_name] = parameters -- update with caller of register_me :

	do 	-- rewrite to file :
		file, err_msg = io.open(fname, "w")
		if file then
			-- the line under produce a human readable file AND a deserializable table for minetest :)
			file:write("return "..dump(mods2call))
			file:close()
		else
			minetest.log("shape_me_linker:register_me error writing file. io.open say: \n"..err_msg)
			return false, "error writing file, io.open say "..err_msg
		end
		-- shape_me.mydebug("log", "shape_me_linker ; register_me(): mod "..mod_name.." added to "..file_full_name)
	end
	
	-- test to access file : Ok: the access is granted to mod_name's folder
	fname = minetest.get_modpath(mod_name).."/testfile.txt"
	file = io.open(fname, "w")
	if file then
		file:write("Test writing file from shape_me_linker:register_me() function,\n"..
			"called by foreign mod "..mod_name)
		file:close()
	end
	local listfiles = minetest.get_dir_list(minetest.get_modpath("shape_me"),false)
	minetest.log("list files in shape_me dir :"..dump(listfiles))
	fname = minetest.get_modpath("shape_me").."/load_time.lua"
	file = io.open(fname,"r")
	if file then 
		minetest.log("read shape_me load_time.lua file ok")
		file:close()
	end
	return true
end

shape_me.mydebug("log", "shape_me_linker : init loaded.")